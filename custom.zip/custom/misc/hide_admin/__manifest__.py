# -*- coding: utf-8 -*-
{
    'name': 'Hide Admin User',
    'version': '1.0.0',
    'author': 'Francis Bangura',
    "category": "Access",
    'website': 'https://byteltd.com',
    'depends': [],
    'data': [
        'views/views.xml',
        'security/security.xml',
    ],
    'installable': True
}
