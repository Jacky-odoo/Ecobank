Status Bar Clock
----------------------

Odoo Version : Odoo 10.0 Community


Installation 
-------------

Install the Application => Apps -> Status Bar Clock


Functionalities
---------------

-> A new field has been added in res.company model.
-> Using that field you can set your date format as you want.
-> It has been added in language view.
-> Date and Time will be displayed according to systems date and time.
