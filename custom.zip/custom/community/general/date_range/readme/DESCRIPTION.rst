This module lets you define global date ranges that can be used to filter
your values in tree views.
