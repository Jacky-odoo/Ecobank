# -*- coding: utf-8 -*-
# Copyright Anubía, soluciones en la nube,SL (http://www.anubia.es)
# Alejandro Santana <alejandrosantana@anubia.es>
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).
