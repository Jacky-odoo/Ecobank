# -*- coding: utf-8 -*-
from . import abstract_report_xlsx
