# -*- coding: utf-8 -*-
from . import account_asset_gl_posting_report_xls
#from . import account_asset_details
