# -*- coding: utf-8 -*-
from . import account_asset_report_xls
from . import account_asset_depreciation_report_xls
from . import account_asset_register_report_xls

