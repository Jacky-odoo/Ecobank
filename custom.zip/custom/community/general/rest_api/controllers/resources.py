import auth
from . import model__res_partner
from . import model__res_users
"""
from .import model__auto_mechanic
from . import model__auto_payment
from . import model__auto_service
from . import model__auto_subscription
from . import model__auto_towing
from . import model__auto_towing_resource
from . import model__auto_user
from . import model__auto_vehicle
from . import model__auto_vehicle_brand
from . import model__auto_vehicle_model
from . import model__auto_vehicle_spare_part
from . import model__auto_spare_part_purchase
from . import model__auto_spare_part_purchase_line
"""



# Uncomment to availability:

#import model__account_invoice       # need install 'account' module
#import model__account_invoice_line  # need install 'account' module
#import model__product_template      # need install 'product' module

#import model__sale_order            # need install 'sale' module
#import model__sale_order_line       # need install 'sale' module
