v1.0.27
=======
* Fix casting issue with many2one fields

v1.0.26
=======
* Fix server action submit action

v1.0.25
=======
* Encoding issue

v1.0.24
=======
* Remove duplicate my_pie and proto nutural the process url

v1.0.23
=======
* Form fields are forced required if they are backend required

v1.0.22
=======
* Date field use server date format

v1.0.21
=======
* Resolve dropbox malformed external html generation

v1.0.20
=======
* Resolve CSRF issue for public users

v1.0.19
=======
* Remove http: so websites that start http then go to https don't get blocked

v1.0.18
=======
* External ReCapatcha code

v1.0.17
=======
* CSRF token loaded via javascript because request.csrf_token causes form to be non removable

v1.0.16
=======
* Required tickbox fix

v1.0.15
=======
* UTF 8 checkbox group fix
* Add external form checkbox group generation / processing

v1.0.14
=======
* Single checkbox in checkbox group process fix

v1.0.13
=======
* Add filename of binary fields

v1.0.12
=======
* Fixed empty input group issue

v1.0.11
=======
* Binary fields in input groups

v1.0.10
=======
* Integer and float validation

v1.0.9
======
* Recode recapatcha javascript so it doesn't depend on rpc (not more alert dialog)

v1.0.8
======
* User and partner access in default values

v1.0.7
======
* Recaptcha and telephone

v1.0.6
======
* Fix issue with dropbox(selection/m2o) and date field when generated from backend

v1.0.5
======
* Fix issue with binary files and public users

v1.0.4
======
* pass values to server action

v1.0.3
======
* Fix public csrf form submit issue

v1.0.2
======
* Fix external embed forms

v1.0.1
======
* Fix adding form action issue

v1.0
====
* Version 10 Upgrade