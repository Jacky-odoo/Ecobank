from . import asset_details_report
