{
    'name': 'Asset Tools for Ecobank',
    'version': '10.0.1.0.0',
    'category': 'Accounts And Finance',
    'summary': 'Ecobank Asset Tools',
    'author': 'Francis Bangura<francis@byteltd.com>',
    'website': 'http://byteltd.com',
    'depends': [],
    'data': [
        'wizard/asset_tool_view.xml'
    ],
    'installable': True,
}
