# -*- coding: utf-8 -*-
from . import fixed_asset_import
