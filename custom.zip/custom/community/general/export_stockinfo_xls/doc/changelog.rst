Changelog
=========
`10.0.2.0.0`
------------
- Total sold & Total purchased counts corrected.
- Added name for sheet.


`9.0.2.0.0`
-----------
- Total sold & Total purchased counts corrected.
- Added name for sheet.
