# -*- coding: utf-8 -*-
{
    'name': "Web Freeze List View Header",

    'summary': """
        To freeze list view's header, very helpful when dealing with many record.
    """,

    'description': """
        To freeze list view's header, very helpful when dealing with many record.
    """,

    'author': "MAXodoo, Vnsoft, osbzr",
    'website': "http://www.maxodoo.com",
    'category': 'web',
    'version': '10.0.0.1',
    'depends': ['web','base'],
    'data': [
        'views/max_web_freeze_list_view_header_view.xml',
    ],
}
