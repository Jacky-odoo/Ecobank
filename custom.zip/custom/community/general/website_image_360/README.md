Odoo 10.0 Community

Installation 
============
* Install the Application => Apps -> Website 360 Image (Technical Name: website_image_360)


Feature
=======
* Added a feature of website's product image 360 rotation in odoo.
* From the product template view, mark "Display 360 Image" boolean as True.
* A new tab will get added from where user can add product's different dimensions images, which will further get display on website.
* After publishing the image on website, user can view the product's 360 dimension image by clicking on a symbol of 360 rotation.


Note: "White Sports Shoes" product has been added through data file with different dimensioned images as an example.
