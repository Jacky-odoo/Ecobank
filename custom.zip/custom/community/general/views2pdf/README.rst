=========================
Views2Pdf v10
=========================
This project aims to give you the possibility to export pdf reports from different views.

Contact
=======

- Linkedin: abderrahmenkhalledi_
- Skype: **a_k_net**
- Email: **abderrahmen.khalledi@gmail.com**

.. _abderrahmenkhalledi: https://www.linkedin.com/in/abderrahmenkhalledi

Installation
============
Installation process is at present stage only possible in manual way.
Then go to your odoo web interface to the module section and start "Update module list". Then look for the "Views2pdf" in Apps (module list) and install.
I hope you enjoy checking out what all you can do with this module.


Prerequisite
============
- Must run command: **npm install save-svg-as-png**

